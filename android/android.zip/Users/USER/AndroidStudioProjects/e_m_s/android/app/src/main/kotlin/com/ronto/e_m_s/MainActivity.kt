package com.ronto.e_m_s

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
